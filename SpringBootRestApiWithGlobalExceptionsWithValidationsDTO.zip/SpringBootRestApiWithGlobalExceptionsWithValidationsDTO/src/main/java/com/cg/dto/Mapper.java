package com.cg.dto;

import com.cg.entity.Customer;

public class Mapper {
	
	//Convert CustomerDTO into Customer Entity
	public static Customer convertDTOTOCustomerEntity(CustomerDTO cust) {
		
		Customer cobj = new Customer();
		//convert Customerdto to Customer entity
		cobj.setCustomerId(cust.getCustomerId());
		cobj.setDateOfBirth(cust.getDateOfBirth());
		cobj.setEmail(cust.getEmail());
		cobj.setName(cust.getName());;
		
		return cobj; //return Customer Object
	}

	//convert the Customer Entity to CustomerDTO
   public static CustomerDTO convertCustomerEntityToDTO(Customer cust) {
		
		CustomerDTO cobj = new CustomerDTO();
		//convert  Customer entity to CustomerDTO
		cobj.setCustomerId(cust.getCustomerId());
		cobj.setDateOfBirth(cust.getDateOfBirth());
		cobj.setEmail(cust.getEmail());
		cobj.setName(cust.getName());;
		
		return cobj; //return CustomerDTO Object 
	}
	
	
	
}
