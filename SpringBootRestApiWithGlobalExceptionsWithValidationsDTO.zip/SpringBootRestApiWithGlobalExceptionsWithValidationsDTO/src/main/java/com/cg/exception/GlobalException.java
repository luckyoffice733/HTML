package com.cg.exception;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.antlr.v4.runtime.atn.ErrorInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import jakarta.validation.ConstraintViolationException;

@RestControllerAdvice
public class GlobalException {

	@Autowired
	private Environment env;

	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleExceptions(CustomerNotFoundException ex) {
		String msg = env.getProperty(ex.getMessage());
		ErrorResponse errResp = new ErrorResponse();
		errResp.setErrorMessage(msg);
		errResp.setErrorCode(HttpStatus.NOT_FOUND.value());
		errResp.setTimeStamp(LocalDateTime.now());

		return new ResponseEntity<>(errResp, HttpStatus.NOT_FOUND);

	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> handleAllExceptions(Exception ex) {
		String msg = env.getProperty("General.EXCEPTION_MESSAGE");
		ErrorResponse errResp = new ErrorResponse();
		errResp.setErrorMessage(msg);
		errResp.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		errResp.setTimeStamp(LocalDateTime.now());

		return new ResponseEntity<>(errResp, HttpStatus.INTERNAL_SERVER_ERROR);

	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorResponse> handleValidationException(MethodArgumentNotValidException mnve) {

		BindingResult br = mnve.getBindingResult();
		List<ObjectError> oal = br.getAllErrors();
		Stream<ObjectError> st = oal.stream();
		String msg1 = st.map(s -> s.getDefaultMessage()).collect(Collectors.joining("|"));

		// String msg= mnve.getBindingResult().getAllErrors().stream().map(s ->
		// s.getDefaultMessage()).collect(Collectors.joining(","));
		ErrorResponse eResponse = new ErrorResponse();
		eResponse.setTimeStamp(LocalDateTime.now());
		eResponse.setErrorCode(HttpStatus.BAD_REQUEST.value());
		eResponse.setErrorMessage(msg1);

		return new ResponseEntity<>(eResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<ErrorResponse> pathExceptionHandler(ConstraintViolationException exception) {

		ErrorResponse errorInfo = new ErrorResponse();
		errorInfo.setErrorCode(HttpStatus.BAD_REQUEST.value());

		String errorMsg = exception.getConstraintViolations().stream().map(x -> x.getMessage())
				.collect(Collectors.joining(", "));
		errorInfo.setErrorMessage(errorMsg);
		errorInfo.setTimeStamp(LocalDateTime.now());
		return new ResponseEntity<>(errorInfo, HttpStatus.BAD_REQUEST);

	}

}
