package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dto.CustomerDTO;
import com.cg.dto.Mapper;
import com.cg.entity.Customer;
import com.cg.exception.CustomerNotFoundException;
import com.cg.repo.CustomerRepo;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerRepo customerRepo;

	@Override
	public Long addCustomer(CustomerDTO cust) {
		Customer cobj = Mapper.convertDTOTOCustomerEntity(cust);
		/*
		 * //convert Customerdto to Customer entity
		 * cobj.setDateOfBirth(cust.getDateOfBirth()); cobj.setEmail(cust.getEmail());
		 * cobj.setName(cust.getName());;
		 */
		
		Customer customer=  customerRepo.save(cobj);
		
		return customer.getCustomerId();
	}

	@Override
	public List<CustomerDTO> getAllCustomers() throws CustomerNotFoundException{
	
		List<Customer> lst =customerRepo.findAll();
		List<CustomerDTO> al=new ArrayList<>();
		if(lst.isEmpty()) {
			throw new CustomerNotFoundException("Service.CUSTOMERS_NOT_FOUND");
		}
		else {
			for(Customer c:lst) {
				CustomerDTO cdto = Mapper.convertCustomerEntityToDTO(c);
				/*
				 * cdto.setCustomerId(c.getCustomerId()); cdto.setEmail(c.getEmail());
				 * cdto.setName(c.getName()); cdto.setDateOfBirth(c.getDateOfBirth());
				 */
				
				al.add(cdto);
			}
		}
		
		return al;
		
	}

	@Override
	public CustomerDTO getCustomerById(Long id)throws CustomerNotFoundException {
	
	Optional<Customer> optal=customerRepo.findById(id);
	 Customer cust = optal.orElseThrow(()-> new CustomerNotFoundException("Service.CUSTOMER_NOT_FOUND"));
	/*
	 * if(optal.isPresent()) { return optal.get(); }else { throw new
	 * CustomerNotFoundException("Customer Not Found Based On Id"); }
	 * 
	 */
	 //convert entity into dto
	// CustomerDTO cdto = new CustomerDTO();
	 CustomerDTO cdto =Mapper.convertCustomerEntityToDTO(cust);
		/*
		 * cdto.setCustomerId(cust.getCustomerId()); cdto.setEmail(cust.getEmail());
		 * cdto.setName(cust.getName()); cdto.setDateOfBirth(cust.getDateOfBirth());
		 */
	 
	 return cdto;
	
	}

	@Override
	public void deleteCustomer(Long id) throws CustomerNotFoundException {
	Optional<Customer> optial=	 customerRepo.findById(id);
		
	Customer cust = optial.orElseThrow(() -> new CustomerNotFoundException("Service.CUSTOMER_NOT_FOUND"));
	
	 customerRepo.deleteById(id);
	
	}

	@Override
	public void updateCustomer(Long id, String email) throws CustomerNotFoundException {
		Optional<Customer> optial=	 customerRepo.findById(id);
		Customer cust = optial.orElseThrow(() -> new CustomerNotFoundException("Service.CUSTOMER_NOT_FOUND"));
		
		cust.setEmail(email);
		customerRepo.save(cust);
		
	}

}
