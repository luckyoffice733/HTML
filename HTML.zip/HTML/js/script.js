
function empdetails(){
    document.writeln('we are in empdetails <br>')
    var fname=   document.getElementById("fn").textContent;
    var lname= document.getElementById("ln").textContent;

    //var fname = document.getElementsByClassName("f1").text

document.writeln(fname+" "+lname);
}